#!/bin/bash
echo "Hello $USER I am running on node $HOSTNAME"
# echo "waiting for 10 seconds"
# sleep 10
echo "successfully finished!"
